"""Test the AI extraction on a pasted message without WhatsApp, and see what it costs:

    docker compose exec app python -m app.try_parse "WTS 🇭🇰 126710BLNR 2024 full set hkd128k"
    docker compose exec app python -m app.try_parse < message.txt
"""
import asyncio
import json
import sys

from .config import settings
from .parser import extract_batch, looks_like_offer
from .worker import clean_offer


async def main() -> None:
    text = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else sys.stdin.read()
    if not looks_like_offer(text):
        print("prefilter: SKIP — no watch offer detected, the AI would not be called (cost $0)")
        return
    res, usage = await extract_batch([(text, None)])
    print(json.dumps([clean_offer(o) for o in res[0]], indent=2, ensure_ascii=False))
    cost = usage["input_tokens"] / 1e6 * settings.PRICE_IN_PER_M + usage["output_tokens"] / 1e6 * settings.PRICE_OUT_PER_M
    print(f"\ntokens in/out: {usage['input_tokens']}/{usage['output_tokens']}  ≈ ${cost:.4f} for this call "
          f"(in the live feed up to {settings.AI_BATCH_SIZE} messages share one call, so each costs less)")


if __name__ == "__main__":
    asyncio.run(main())
