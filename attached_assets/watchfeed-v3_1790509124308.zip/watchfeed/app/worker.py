"""Background loop: parse NEW messages into offers."""
import asyncio
import hashlib
import json
import logging
from datetime import timedelta
from typing import Optional

import httpx
from sqlalchemy import select

from . import alerts, fx, market, media, refs
from .config import settings
from .db import Group, Message, Offer, ParseCache, SessionLocal, utcnow
from .parser import ParseError, extract_batch, looks_like_offer

log = logging.getLogger("worker")

CONDITIONS = {"NEW", "LIKE_NEW", "USED", "VINTAGE"}
SET_TYPES = {"FULL_SET", "WATCH_ONLY", "BOX_ONLY", "PAPERS_ONLY"}


from .worker_utils import norm_ref  # noqa: E402,F401  (re-exported)


def _s(v, n=200) -> Optional[str]:
    if v is None:
        return None
    v = str(v).strip()
    return v[:n] or None


def clean_offer(o: dict) -> Optional[dict]:
    if not isinstance(o, dict):
        return None
    direction = str(o.get("direction") or "WTS").upper()
    if direction not in ("WTS", "WTB"):
        direction = "WTS"
    brand, ref = _s(o.get("brand"), 80), _s(o.get("reference"), 80)
    family, model = _s(o.get("family"), 120), _s(o.get("model"), 200)
    if not (brand or ref or family or model):
        return None
    year = o.get("year")
    try:
        year = int(year) if year is not None else None
        if year is not None and year < 100:
            year += 2000
        if year is not None and not (1900 <= year <= utcnow().year + 1):
            year = None
    except (TypeError, ValueError):
        year = None
    month = o.get("month")
    try:
        month = int(month) if month is not None and 1 <= int(month) <= 12 else None
    except (TypeError, ValueError):
        month = None
    try:
        price = float(o["price"]) if o.get("price") not in (None, "") else None
        if price is not None and price <= 0:
            price = None
    except (TypeError, ValueError):
        price = None
    currency = fx.normalize_currency(o.get("currency")) if price is not None else None
    try:
        disc = float(o["discount_pct"]) if o.get("discount_pct") is not None else None
    except (TypeError, ValueError):
        disc = None
    cond = str(o.get("condition") or "").upper() or None
    st = str(o.get("set_type") or "").upper() or None
    country = str(o.get("country") or "").upper()[:2] or None
    known_brand, known_family = refs.lookup(norm_ref(ref), brand)
    if known_family:
        brand, family = known_brand, known_family
    return {
        "direction": direction, "brand": brand, "family": family, "model": model,
        "reference": ref, "reference_norm": norm_ref(ref),
        "dial_color": _s(o.get("dial_color"), 80), "case_material": _s(o.get("case_material"), 80),
        "bracelet": _s(o.get("bracelet"), 80), "diamond_indices": bool(o.get("diamond_indices")),
        "condition": cond if cond in CONDITIONS else None,
        "set_type": st if st in SET_TYPES else None,
        "year": year, "month": month, "price": price, "currency": currency,
        "price_base": fx.to_base(price, currency), "discount_pct": disc,
        "country": country if country and country.isalpha() else None,
        "city": _s(o.get("city"), 80), "notes": _s(o.get("notes"), 500),
        "source_text": (_s(o.get("source_text"), 2000) or ""),
    }


def fingerprint(o: dict, dealer: str) -> str:
    parts = [o["direction"], o["reference_norm"] or (o["brand"] or "") + (o["model"] or ""),
             o["dial_color"] or "", str(o["price"] or ""), o["currency"] or "",
             o["condition"] or "", o["set_type"] or "", str(o["year"] or ""), dealer]
    return hashlib.sha1("|".join(p.lower() for p in parts).encode()).hexdigest()


def compute_market_pct(s, o: dict, dealer_key: str, ts) -> Optional[float]:
    if o["direction"] != "WTS" or not o["price_base"] or not o["reference_norm"]:
        return None
    rows = s.execute(select(Offer.price_base, Offer.condition, Offer.set_type).where(
        Offer.reference_norm == o["reference_norm"], Offer.direction == "WTS", Offer.price_base.is_not(None),
        Offer.last_seen_at >= ts - timedelta(days=30), Offer.dealer_key != dealer_key)).all()
    comps = [market.normalize(p, c, st) for p, c, st in rows]
    return market.market_pct(market.normalize(o["price_base"], o["condition"], o["set_type"]), comps)


def save_offers(s, msg: Message, raw_offers: list) -> tuple:
    """Returns (offers_found, [newly created Offer rows])."""
    dealer_key = media.sender_key(msg.sender_phone, msg.sender_name) or ""
    window = msg.ts - timedelta(days=settings.DUPLICATE_WINDOW_DAYS)
    count, new, touched = 0, [], []
    for raw in raw_offers:
        o = clean_offer(raw)
        if not o:
            continue
        fp = fingerprint(o, dealer_key)
        existing = s.scalar(select(Offer).where(Offer.fingerprint == fp, Offer.last_seen_at >= window)
                            .order_by(Offer.last_seen_at.desc()).limit(1))
        if existing:
            existing.duplicate_count += 1
            if msg.ts > existing.last_seen_at:
                existing.last_seen_at = msg.ts
            if msg.ts < existing.first_seen_at:
                existing.first_seen_at = msg.ts
            seen = set(filter(None, existing.groups_seen.split(",")))
            seen.add(msg.group_id)
            existing.groups_seen = ",".join(sorted(seen))
            touched.append(existing)
        else:
            row = Offer(message_id=msg.id, group_id=msg.group_id, groups_seen=msg.group_id,
                        dealer_name=msg.sender_name, dealer_phone=msg.sender_phone, dealer_key=dealer_key or None,
                        market_pct=compute_market_pct(s, o, dealer_key, msg.ts),
                        fingerprint=fp, first_seen_at=msg.ts, last_seen_at=msg.ts, **o)
            s.add(row)
            new.append(row)
            touched.append(row)
        count += 1
    if touched:
        s.flush()
        media.link_for_message(s, msg, touched)
    return count, new


def _chunks(items: list) -> list:
    """Split messages into AI batches by count and size."""
    out, cur, size = [], [], 0
    for m in items:
        n = min(len(m.text), settings.MAX_MESSAGE_CHARS)
        if cur and (len(cur) >= settings.AI_BATCH_SIZE or size + n > settings.AI_BATCH_CHARS):
            out.append(cur)
            cur, size = [], 0
        cur.append(m)
        size += n
    if cur:
        out.append(cur)
    return out


async def _run_batch(batch: list, names: dict, client, sem) -> dict:
    """-> {text_hash: ("OK", offers, tokens_in, tokens_out) | ("ERROR", msg, 0, 0)}. Splits in half if too long."""
    try:
        async with sem:
            res, usage = await extract_batch([(m.text, names.get(m.group_id, "")) for m in batch], client)
    except ParseError as e:
        if str(e) == "too long" and len(batch) > 1:
            half = len(batch) // 2
            a = await _run_batch(batch[:half], names, client, sem)
            b = await _run_batch(batch[half:], names, client, sem)
            return {**a, **b}
        return {m.text_hash: ("ERROR", str(e), 0, 0) for m in batch}
    except Exception as e:  # noqa: BLE001
        log.exception("AI batch failed")
        return {m.text_hash: ("ERROR", repr(e), 0, 0) for m in batch}
    total = sum(len(m.text) for m in batch) or 1
    out = {}
    for m, offers in zip(batch, res):
        share = len(m.text) / total  # split the bill by message length
        out[m.text_hash] = ("OK", offers, round(usage["input_tokens"] * share), round(usage["output_tokens"] * share))
    return out


async def process_batch(limit: int = 40) -> tuple:
    """Returns (processed, errors)."""
    with SessionLocal() as s:
        msgs = s.scalars(select(Message).where(Message.status == "NEW")
                         .order_by(Message.ts).limit(limit)).all()
        groups = {g.id: g for g in s.scalars(select(Group)).all()}
    if not msgs:
        return 0, 0
    names = {k: g.name for k, g in groups.items()}
    results = {}  # text_hash -> (status, data, tin, tout)
    need_ai = {}
    for m in msgs:
        if m.text_hash in results or m.text_hash in need_ai:
            continue
        g = groups.get(m.group_id)
        if not looks_like_offer(m.text):
            results[m.text_hash] = ("SKIPPED", None, 0, 0)
        elif g is not None and g.ai_paused:
            results[m.text_hash] = ("PAUSED", None, 0, 0)
        else:
            with SessionLocal() as s:
                cached = s.get(ParseCache, m.text_hash)
            if cached:
                results[m.text_hash] = ("OK", json.loads(cached.result_json), 0, 0)
            else:
                need_ai[m.text_hash] = m
    if need_ai:
        sem = asyncio.Semaphore(settings.LLM_CONCURRENCY)
        async with httpx.AsyncClient(timeout=180) as client:
            parts = await asyncio.gather(*[_run_batch(b, names, client, sem) for b in _chunks(list(need_ai.values()))])
        with SessionLocal() as s:
            for part in parts:
                for h, r in part.items():
                    results[h] = r
                    if r[0] == "OK" and not s.get(ParseCache, h):
                        s.add(ParseCache(text_hash=h, result_json=json.dumps(r[1])))
            s.commit()
    errors, new_ids, billed = 0, [], set()
    with SessionLocal() as s:
        for m in msgs:
            status, data, tin, tout = results[m.text_hash]
            msg, created = s.get(Message, m.id), []
            if m.text_hash not in billed:  # tokens counted once per unique text
                msg.tokens_in, msg.tokens_out = tin, tout
                billed.add(m.text_hash)
            if status in ("SKIPPED", "PAUSED"):
                msg.status = status
            elif status == "ERROR":
                errors += 1
                msg.attempts += 1
                msg.error = (data or "")[:1000]
                if msg.attempts >= 3:
                    msg.status = "ERROR"
            else:
                n, created = save_offers(s, msg, data or [])
                msg.offers_count = n
                msg.status = "PARSED" if n else "NO_OFFERS"
                msg.error = None
                g = s.get(Group, msg.group_id)
                if g is not None and (tin or tout):
                    g.ai_checked = (g.ai_checked or 0) + 1
                    g.ai_hits = (g.ai_hits or 0) + (1 if n else 0)
                    if settings.AUTO_PAUSE_AFTER and g.ai_checked >= settings.AUTO_PAUSE_AFTER and not g.ai_hits:
                        g.ai_paused = True
                        log.info("AI paused for group %s: no watches in %d messages", g.name, g.ai_checked)
            s.commit()
            if status == "OK":
                new_ids += [o.id for o in created]
    if new_ids:
        try:
            await alerts.process_new_offers(new_ids)
        except Exception:  # noqa: BLE001 - alerts must never stop parsing
            log.exception("alert processing failed")
    return len(msgs), errors


async def run_forever() -> None:
    log.info("worker started")
    last_fx = last_house = None
    last_clean = None
    while True:
        try:
            if last_fx is None or utcnow() - last_fx > timedelta(hours=12):
                await fx.refresh()
                last_fx = utcnow()
            if last_house is None or utcnow() - last_house > timedelta(minutes=5):
                last_house = utcnow()
                await alerts.maybe_send_digest()
                if utcnow().hour == 3 and last_clean != utcnow().date():  # nightly photo cleanup
                    last_clean = utcnow().date()
                    with SessionLocal() as s:
                        media.cleanup(s)
            n, errors = await process_batch()
            if errors:
                await asyncio.sleep(30)
            elif n == 0:
                await asyncio.sleep(3)
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001
            log.exception("worker loop error")
            await asyncio.sleep(10)
