"""Saved-search alerts, stock matches and the morning summary. Sent by email and/or Telegram.

The WhatsApp number is never used to send anything - the tool stays read-only."""
import asyncio
import html
import json
import logging
import os
import smtplib
from datetime import datetime, timedelta
from email.message import EmailMessage
from typing import Optional
from zoneinfo import ZoneInfo

import httpx
from sqlalchemy import func, select

from . import market, worker_utils
from .config import settings
from .db import KV, Alert, AlertHit, Dealer, Offer, Photo, SessionLocal, StockItem, utcnow

log = logging.getLogger("alerts")

COND = {"NEW": "New", "LIKE_NEW": "Like new", "USED": "Pre-owned", "VINTAGE": "Vintage"}
SETS = {"FULL_SET": "Full set", "WATCH_ONLY": "Watch only", "BOX_ONLY": "Watch + box", "PAPERS_ONLY": "Watch + papers"}
SYMBOL = {"GBP": "£", "USD": "$", "EUR": "€", "HKD": "HK$"}


# ------------------------------------------------------------------ matching
def offer_matches(o: dict, q: dict) -> bool:
    """o: offer dict (see offer_dict). q: the same filters the feed uses."""
    if q.get("direction") and o["direction"] != q["direction"]:
        return False
    if q.get("brand") and o.get("brand") != q["brand"]:
        return False
    for k in ("condition", "set_type", "country"):
        if q.get(k) and (o.get(k) or "") not in str(q[k]).upper().split(","):
            return False
    pb = o.get("price_base")
    if q.get("min_price") not in (None, "") and (pb is None or pb < float(q["min_price"])):
        return False
    if q.get("max_price") not in (None, "") and (pb is None or pb > float(q["max_price"])):
        return False
    if q.get("priced_only") and pb is None:
        return False
    y = o.get("year")
    if q.get("year_from") not in (None, "") and (y is None or y < int(q["year_from"])):
        return False
    if q.get("year_to") not in (None, "") and (y is None or y > int(q["year_to"])):
        return False
    if q.get("deals_only") and market.deal_label(o.get("market_pct"), settings.DEAL_THRESHOLD_PCT) != "DEAL":
        return False
    if q.get("group") and q["group"] not in (o.get("groups_seen") or ""):
        return False
    hay = " ".join(str(o.get(k) or "") for k in ("brand", "family", "model", "dial_color", "case_material",
                                                 "source_text", "dealer_name", "dealer_phone")).lower()
    for tok in str(q.get("q") or "").split():
        ref = worker_utils.norm_ref(tok)
        if tok.lower() not in hay and not (ref and ref in (o.get("reference_norm") or "")):
            return False
    return True


def offer_dict(o: Offer) -> dict:
    return {c: getattr(o, c) for c in (
        "id", "direction", "brand", "family", "model", "reference", "reference_norm", "dial_color", "case_material",
        "condition", "set_type", "year", "price", "currency", "price_base", "country", "source_text",
        "dealer_name", "dealer_phone", "dealer_key", "groups_seen", "market_pct", "photo_id")}


# ------------------------------------------------------------------ formatting
def money(v: Optional[float], cur: Optional[str]) -> str:
    if v is None:
        return ""
    return f"{SYMBOL.get(cur or '', (cur or '') + ' ')}{v:,.0f}"


def offer_line(o: dict) -> str:
    title = " ".join(x for x in (o.get("brand"), o.get("family")) if x)
    bits = [f"{o['direction']} {title} {o.get('reference') or ''}".strip(),
            COND.get(o.get("condition"), ""), SETS.get(o.get("set_type"), ""), str(o.get("year") or "")]
    if o.get("price") is not None:
        p = money(o["price"], o.get("currency"))
        if o.get("currency") != settings.BASE_CURRENCY and o.get("price_base"):
            p += f" ({money(o['price_base'], settings.BASE_CURRENCY)})"
        bits.append(p)
    lab = market.deal_label(o.get("market_pct"), settings.DEAL_THRESHOLD_PCT)
    if lab == "DEAL":
        bits.append(f"DEAL {o['market_pct'] * 100:.0f}% vs market")
    who = " ".join(x for x in (o.get("dealer_name"), f"+{o['dealer_phone']}" if o.get("dealer_phone") else None) if x)
    if who:
        bits.append(who)
    return " · ".join(b for b in bits if b)


def link(path: str) -> str:
    return f"{settings.PUBLIC_URL}{path}" if settings.PUBLIC_URL else ""


# ------------------------------------------------------------------ senders
def _send_email_sync(to: list, subject: str, text: str) -> None:
    msg = EmailMessage()
    msg["From"] = settings.SMTP_FROM or settings.SMTP_USER
    msg["To"] = ", ".join(to)
    msg["Subject"] = subject
    msg.set_content(text)
    with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT, timeout=30) as smtp:
        smtp.starttls()
        if settings.SMTP_USER:
            smtp.login(settings.SMTP_USER, settings.SMTP_PASSWORD)
        smtp.send_message(msg)


async def send_email(to: list, subject: str, text: str) -> bool:
    to = [t.strip() for t in to if t and t.strip()]
    if not (to and settings.SMTP_HOST):
        return False
    try:
        await asyncio.to_thread(_send_email_sync, to, subject, text)
        return True
    except Exception as e:  # noqa: BLE001
        log.warning("email failed: %s", e)
        return False


async def send_telegram(text: str, photo_path: Optional[str] = None, chat_id: Optional[str] = None) -> bool:
    chat = chat_id or settings.TELEGRAM_CHAT_ID
    if not (settings.TELEGRAM_BOT_TOKEN and chat):
        return False
    base = f"https://api.telegram.org/bot{settings.TELEGRAM_BOT_TOKEN}"
    try:
        async with httpx.AsyncClient(timeout=30) as c:
            if photo_path:
                with open(photo_path, "rb") as f:
                    r = await c.post(f"{base}/sendPhoto", data={"chat_id": chat, "caption": text[:1000], "parse_mode": "HTML"},
                                     files={"photo": ("watch.jpg", f, "image/jpeg")})
            else:
                r = await c.post(f"{base}/sendMessage", json={"chat_id": chat, "text": text[:4000], "parse_mode": "HTML",
                                                              "disable_web_page_preview": True})
            r.raise_for_status()
        return True
    except Exception as e:  # noqa: BLE001
        log.warning("telegram failed: %s", e)
        return False


def channels_configured() -> dict:
    return {"email": bool(settings.SMTP_HOST), "telegram": bool(settings.TELEGRAM_BOT_TOKEN and settings.TELEGRAM_CHAT_ID)}


# ------------------------------------------------------------------ new offers -> alerts + stock matches
def _photo_path(s, photo_id: Optional[int]) -> Optional[str]:
    if not photo_id:
        return None
    p = s.get(Photo, photo_id)
    return os.path.join(settings.MEDIA_DIR, p.thumb) if p else None


async def process_new_offers(offer_ids: list) -> int:
    """Called by the worker after new offers are saved. Returns number of notifications sent."""
    if not offer_ids:
        return 0
    sent = 0
    outbox = []  # (alert_or_None, title, [offer dicts], emails, telegram, photo)
    with SessionLocal() as s:
        blocked = set(s.scalars(select(Dealer.key).where(Dealer.rating == "BLOCKED")).all())
        offers = [offer_dict(o) for o in s.scalars(select(Offer).where(Offer.id.in_(offer_ids))).all()]
        offers = [o for o in offers if o.get("dealer_key") not in blocked]
        for a in s.scalars(select(Alert).where(Alert.active.is_(True))).all():
            try:
                q = json.loads(a.query_json)
            except ValueError:
                continue
            hits = [o for o in offers if offer_matches(o, q)]
            if not hits:
                continue
            for o in hits:
                s.add(AlertHit(alert_id=a.id, offer_id=o["id"]))
            a.hit_count += len(hits)
            a.last_hit_at = utcnow()
            photo = _photo_path(s, hits[0]["photo_id"]) if len(hits) == 1 else None
            outbox.append((f"🔔 {a.name}", hits, a.emails.split(","), a.telegram, photo))
        # WTB requests for watches we hold
        stock = {}
        for it in s.scalars(select(StockItem).where(StockItem.status == "ACTIVE")).all():
            stock.setdefault(it.reference_norm, []).append(it)
        wtb = [o for o in offers if o["direction"] == "WTB" and o.get("reference_norm") in stock]
        for o in wtb:
            items = stock[o["reference_norm"]]
            outbox.append((f"📦 Dealer wants a watch in our stock ({items[0].reference})", [o],
                           settings.DIGEST_EMAILS.split(","), True, None))
        s.commit()
    for title, hits, emails, tg, photo in outbox:
        lines = [offer_line(o) for o in hits[:10]]
        more = f"\n…and {len(hits) - 10} more" if len(hits) > 10 else ""
        url = link("/")
        text = f"{title}\n\n" + "\n\n".join(lines) + more + (f"\n\n{url}" if url else "")
        tg_text = f"<b>{html.escape(title)}</b>\n\n" + "\n\n".join(html.escape(x) for x in lines) + html.escape(more)
        if tg and await send_telegram(tg_text, photo):
            sent += 1
        if await send_email(emails, title, text):
            sent += 1
    return sent


# ------------------------------------------------------------------ morning summary
def build_digest(s, now: datetime) -> dict:
    day, week = now - timedelta(days=1), now - timedelta(days=7)
    blocked = set(s.scalars(select(Dealer.key).where(Dealer.rating == "BLOCKED")).all())
    recent = [o for o in s.scalars(select(Offer).where(Offer.first_seen_at >= day, Offer.archived.is_(False))).all()
              if o.dealer_key not in blocked]
    deals = sorted([o for o in recent if market.deal_label(o.market_pct, settings.DEAL_THRESHOLD_PCT) == "DEAL"],
                   key=lambda o: o.market_pct)[:10]
    wanted = s.execute(select(Offer.reference, func.count(func.distinct(Offer.dealer_key)).label("n"))
                       .where(Offer.direction == "WTB", Offer.last_seen_at >= week, Offer.reference.is_not(None))
                       .group_by(Offer.reference).order_by(func.count(func.distinct(Offer.dealer_key)).desc())
                       .limit(10)).all()
    rows = s.execute(select(Offer.reference_norm, Offer.reference, Offer.brand, Offer.family, Offer.last_seen_at,
                            Offer.price_base, Offer.condition, Offer.set_type)
                     .where(Offer.direction == "WTS", Offer.last_seen_at >= now - timedelta(days=28),
                            Offer.price_base.is_not(None))).all()
    mv = market.movers([(r[0], r[1], r[2], r[3], r[4], market.normalize(r[5], r[6], r[7])) for r in rows], now)
    stock_refs = set(s.scalars(select(StockItem.reference_norm).where(StockItem.status == "ACTIVE")).all())
    stock_wtb = [o for o in recent if o.direction == "WTB" and o.reference_norm in stock_refs]
    return {"new_offers": len(recent), "wts": sum(o.direction == "WTS" for o in recent),
            "wtb": sum(o.direction == "WTB" for o in recent),
            "deals": [offer_dict(o) for o in deals], "wanted": [(r, n) for r, n in wanted],
            "movers": mv, "stock_wtb": [offer_dict(o) for o in stock_wtb]}


def render_digest(d: dict, date_str: str) -> str:
    out = [f"Watch market summary — {date_str}",
           f"{d['new_offers']} new offers in 24h ({d['wts']} for sale, {d['wtb']} wanted)", ""]
    if d["deals"]:
        out.append("BEST DEALS (priced below other dealers)")
        out += [f"• {offer_line(o)}" for o in d["deals"]] + [""]
    if d["stock_wtb"]:
        out.append("DEALERS WANTING WATCHES WE HOLD")
        out += [f"• {offer_line(o)}" for o in d["stock_wtb"]] + [""]
    if d["wanted"]:
        out.append("MOST WANTED THIS WEEK (dealers asking to buy)")
        out += [f"• {ref}: {n} dealers" for ref, n in d["wanted"]] + [""]
    if d["movers"]:
        out.append("PRICE MOVES (last 7 days vs previous 3 weeks)")
        out += [f"• {m['reference']} {m['family'] or ''}: {m['change_pct']:+.1f}% "
                f"(typical {money(m['now'], settings.BASE_CURRENCY)})" for m in d["movers"]] + [""]
    url = link("/")
    if url:
        out.append(f"Open the feed: {url}")
    return "\n".join(out)


async def maybe_send_digest(now_utc: Optional[datetime] = None) -> bool:
    tz = ZoneInfo(settings.TIMEZONE)
    local = (now_utc or datetime.utcnow()).replace(tzinfo=ZoneInfo("UTC")).astimezone(tz)
    if local.hour < settings.DIGEST_HOUR:
        return False
    today = local.date().isoformat()
    with SessionLocal() as s:
        kv = s.get(KV, "digest_last")
        if kv and kv.value == today:
            return False
        d = build_digest(s, utcnow())
        if kv is None:
            kv = KV(key="digest_last", value="")
            s.add(kv)
        kv.value = today
        s.commit()
    text = render_digest(d, local.strftime("%a %d %b"))
    ok_tg = await send_telegram(html.escape(text))
    ok_mail = await send_email(settings.DIGEST_EMAILS.split(","), f"Watch market summary {local:%d %b}", text)
    return ok_tg or ok_mail
