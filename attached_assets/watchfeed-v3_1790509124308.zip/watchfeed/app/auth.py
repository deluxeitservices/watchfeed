"""Browser logins (HTTP Basic). Staff can have individual names so tracking shows who did what."""
import secrets

from fastapi import Depends, HTTPException
from fastapi.security import HTTPBasic, HTTPBasicCredentials

from .config import settings

basic = HTTPBasic()


def staff_accounts() -> dict:
    users = {}
    for pair in settings.STAFF_USERS.split(","):
        if ":" in pair:
            u, p = pair.split(":", 1)
            if u.strip() and p.strip():
                users[u.strip()] = p.strip()
    if settings.STAFF_PASSWORD:
        users.setdefault(settings.STAFF_USER, settings.STAFF_PASSWORD)
    return users


def _eq(a: str, b: str) -> bool:
    return secrets.compare_digest(a.encode(), b.encode())


def _deny():
    raise HTTPException(401, "Unauthorized", headers={"WWW-Authenticate": "Basic"})


def _admin_ok(c: HTTPBasicCredentials) -> bool:
    return bool(settings.ADMIN_PASSWORD) and _eq(c.username, settings.ADMIN_USER) and _eq(c.password, settings.ADMIN_PASSWORD)


def is_admin(creds: HTTPBasicCredentials = Depends(basic)) -> str:
    if not _admin_ok(creds):
        _deny()
    return creds.username


def is_staff(creds: HTTPBasicCredentials = Depends(basic)) -> str:
    """Returns the logged-in username."""
    if _admin_ok(creds):
        return creds.username
    pw = staff_accounts().get(creds.username)
    if pw is None or not _eq(creds.password, pw):
        _deny()
    return creds.username
