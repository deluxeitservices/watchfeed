# Watch Trading Feed

This tool reads your WhatsApp dealer groups. AI pulls every **WTS / WTB** watch out of each message: brand, reference, dial, condition, set, year, price, dealer and the dealer's photo. Staff get:

* **Market feed:** every offer, with photos, deal badges and staff tracking
* **Buy advisor:** what to pay a customer for a watch
* **Alerts:** Telegram and email alerts, plus a morning summary
* **Dealers:** profiles, notes, ratings and a block list
* **Our stock:** see which dealers want the watches we hold

```
Your WhatsApp (linked device) ─► WAHA bridge ─► app (webhook) ─► Postgres
                                                 │
                                                 └─► AI parser (Claude) ─► offers ─► Staff feed  /
                                                                                     Admin      /admin
```

* **Read-only.** It never sends messages.
* **Only groups you tick are stored.** Private chats and unticked groups are dropped.
* **Duplicates are merged.** If the same dealer posts the same watch at the same price in several groups within 14 days, it shows as one offer ("Posts ×3").
* **AI costs are kept down.** Chat like "ok", "thanks" and "good morning" is skipped before the AI sees it. Text copy-pasted into many groups is parsed once.

---

## 1. What you need

| Item | Where | Approx cost |
|---|---|---|
| Small Linux server (2 GB RAM) | Hetzner CX22, DigitalOcean, etc. | £4–10 / month |
| Domain / subdomain, e.g. `feed.yourdomain.co.uk` | A record → server IP | – |
| Anthropic API key | console.anthropic.com → API keys | ~$2–3 per 1,000 offer messages parsed |

## 2. Install (on the server)

```bash
# Docker
curl -fsSL https://get.docker.com | sh

# Project
mkdir -p /opt/watchfeed && cd /opt/watchfeed
# upload the contents of this folder here (scp / git), then:
cp .env.example .env
nano .env            # fill in DOMAIN, passwords, ANTHROPIC_API_KEY
# generate the 3 random secrets:
for k in POSTGRES_PASSWORD WAHA_API_KEY WEBHOOK_SECRET; do sed -i "s|^$k=.*|$k=$(openssl rand -hex 24)|" .env; done

docker compose up -d --build
docker compose logs -f app      # Ctrl+C to exit logs
```

Open `https://feed.yourdomain.co.uk/admin` and log in with ADMIN_USER / ADMIN_PASSWORD.

## 3. Connect WhatsApp and pick groups

1. In **/admin**, click **Connect / show QR**.
2. On your phone, go to WhatsApp → Settings → **Linked devices** → **Link a device**, then scan the QR code. The status changes to **WORKING**.
3. Click **Load groups from WhatsApp**. All groups are listed, and **all start OFF**.
4. Tick the trading groups. Use the filter box with **Enable visible** to switch on many at once. Leave family and friends groups off.
5. Optional: click **Import last 300** on a group to pull in its recent history.

New messages then flow in live. Give each staff member their own login from `STAFF_USERS` (e.g. `ali:pass1,sara:pass2`), so the site records who contacted or bought what.

**Check everything works (recommended once after install):**
```bash
docker compose run --rm app sh -c "pip install -q pytest && pytest -q tests"
```
You should see `N passed`. The tests use a temporary database and never touch your real data.

## 4. Staff feed

* **Search** looks across references, models, dial, dealer name and phone and the raw text. `126710 blnr`, `5711`, `daytona panda` and `+852` all work.
* **Filters:** WTS / WTB, period, brand, condition, set, location, group, price range (GBP), year and "priced only".
* **Sorting:** click a column header.
* **Photos:** each thumbnail is the dealer's own photo. Click it to enlarge.
  * `msg photo`: the photo came with a multi-watch message, so it may show a different watch from the list.
  * `ref photo`: the listing had no photo of its own, so it shows the latest photo seen for that reference.
  * Photos are deleted after `PHOTO_RETENTION_DAYS` (60), except the newest photo of each reference.
* **DEAL −12%:** the listing is priced at least `DEAL_THRESHOLD_PCT` (8%) below what other dealers ask for that reference in the last 30 days. Prices are compared after adjusting for condition and box/papers. `check price` means it's more than 40% below, which is probably a typo. Tick **Deals only** to see just these.
* **Click a reference** to see its weekly price chart (last 6 months), dealer counts and recent listings.
* **Click a dealer** to see their profile. You can rate them ✓ Trusted, OK, ⚠ Caution or ⛔ Blocked and add a note. Blocked dealers disappear from the feed, alerts and Buy Advisor prices (tick **Show blocked** to see them).
* **Open** shows the original message, all photos and **staff tracking**: mark it Contacted, Offered, Bought or Passed, with a note. Everyone sees who is handling it. Tick **Hide handled** to hide these.
* **🔔 Save as alert:** saves the current search and filters. New matching listings are then sent to Telegram and/or email.
* **Dealer phone** opens a WhatsApp chat.

## 5. Buy Advisor (`/advisor`)

Staff use it when a customer offers to sell a watch.

1. Paste the customer's message and click **Fill details from message**, or type the reference, condition, box and papers, year and asking price yourself.
2. Click **Get buy price**. You get:
   * **Offer the customer**: quick-resale price minus your target margin (10% by default, adjustable with the slider).
   * **Maximum**: the most to pay (half the margin).
   * **We can resell quickly at**: the lower quartile of what dealers in your groups are asking. Each asking price is adjusted to this watch's condition and box and papers, from the last 30 days (widened to 90 if there are few).
   * **Verdict** on whether it's a good seller. It's based on dealers wanting to buy vs dealers selling, the 2-week price trend, and how tight prices are.
   * **Verdict on the customer's asking price**: buy / negotiate / too high / walk away.
   * The comparable dealer offers it used, with WhatsApp links.

Settings in `.env`: `TARGET_MARGIN_PCT=10`, and `IMPORT_UPLIFT_PCT=0`. Set `IMPORT_UPLIFT_PCT` to e.g. 3 to add shipping and import costs to overseas dealer prices. Condition and box/papers adjustments are at the top of `app/advisor.py`. Change them to match your experience.

It needs market data. Expect useful results once the feed has run for 1–2 weeks with your groups. It uses dealer **asking** prices, not sold prices, so it's a guide, not a guarantee.

## 6. Alerts and morning summary (`/alerts`)

Alerts are sent by **Telegram** (free, instant on phones) and/or **email**. The WhatsApp number is never used to send anything.

**Telegram setup (5 minutes):**
1. In Telegram, message **@BotFather** and send `/newbot`. Give it a name, and copy the **token** it gives you.
2. Create a Telegram group for staff (e.g. "Watch deals") and add your bot to it.
3. Send any message in that group, then open `https://api.telegram.org/bot<TOKEN>/getUpdates` in a browser. Find `"chat":{"id":-100…`. That number (including the minus sign) is the chat id.
4. In `.env`, set `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID`. Then run `docker compose up -d app`, and click **Send test alert** in /admin.

**Email setup:** fill in `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD` and `SMTP_FROM`. For Gmail, use `smtp.gmail.com`, port 587 and an app password. Put the summary recipients in `DIGEST_EMAILS`.

**What gets sent:**
* **Saved alerts:** every new listing that matches, with its photo when there is one.
* **Stock matches:** "a dealer wants a watch in our stock", sent whenever a WTB matches something on the **Our stock** page.
* **Morning summary** at `DIGEST_HOUR` (8am UK time), covering:
  * new offers in the last 24h
  * best deals
  * dealers wanting watches we hold
  * most-wanted references
  * the biggest price moves this week

  Preview it from the Alerts page.

## 7. Our stock (`/stock`)

Add the watches you hold, or import them as a CSV. The CSV can be exported from Stock Manager and needs the header `reference,description,condition,set_type,year,asking_price`. For each watch you see:
* how many dealers asked to buy that reference in the last 30 days (click to see who)
* what dealers are asking for a similar piece, and whether your price is above or below that

Mark watches **sold** when they go.

## 8. Tuning and troubleshooting

Test the AI on any pasted message:
```bash
docker compose exec app python -m app.try_parse "🇭🇰 WTS 126710BLNR 03/2024 N FS hkd128k"
```
To change the extraction rules (shorthand, currency habits of your groups), edit `SYSTEM_PROMPT` in `app/parser.py`. Then run `docker compose up -d --build app`.

| Problem | Fix |
|---|---|
| Status `SCAN_QR_CODE` again | Your phone logged the device out. Rescan in /admin. |
| Stats show "Failed" rising | Check the API key or credit, then click **Retry failed messages**. |
| Dealer shows no phone | WhatsApp hides some numbers in groups (privacy "LID"). The name still shows. |
| Too many "No offer found" | Normal for chatty groups. They cost one AI call each. Disable pure-chat groups. |
| No photos | Check `docker compose logs app \| grep photo`. Photos only come from enabled groups, and "Import last 300" brings photos too. |
| No alerts arriving | In /admin, click **Send test alert**. If Telegram fails, re-check the token and chat id (the chat id starts with `-100`). |

Backups: `docker compose exec db pg_dump -U watchfeed watchfeed > backup.sql`. Photos are in the Docker volume `watchfeed_media`.

## 9. Important

* This uses WhatsApp's **Linked devices** feature through an unofficial bridge (WAHA). That is against WhatsApp's terms. Read-only use is low risk, but not zero. Keep it read-only, and consider moving to a dedicated number later. To move, just scan with the new phone.
* Open WhatsApp on the phone at least every ~10 days, or linked devices log out.
* Dealer numbers and names are personal data. Keep the feed behind the login and use it internally only.
* The WhatsApp bridge is never exposed to the internet. Only the app is public, via HTTPS (Caddy).

## Files

```
app/main.py       web app + API + webhook
app/ingest.py     WhatsApp payload → stored group message (group filter)
app/parser.py     prefilter + AI extraction prompt/schema
app/worker.py     background parsing, cleaning, dedupe
app/advisor.py    Buy Advisor pricing + verdict
app/market.py     deal detection, weekly price history, price moves
app/media.py      dealer photos: download, thumbnails, linking, cleanup
app/alerts.py     alerts, stock matches, morning summary (Telegram / email)
app/extra.py      API for photos, tracking, dealers, alerts, stock, price history
app/auth.py       staff / admin logins
app/refs.py       reference number -> model lookup
app/fx.py         currency → GBP (ECB rates, refreshed 12-hourly)
app/waha.py       WhatsApp bridge client (QR, groups, history)
app/static/       pages: feed, advisor, alerts, dealers, stock, admin
tests/            end-to-end tests (docker compose run --rm app sh -c "pip install pytest && pytest -q tests")
```
