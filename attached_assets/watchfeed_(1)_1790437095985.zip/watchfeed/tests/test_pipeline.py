import asyncio, base64, os, time
import tempfile
os.environ.update(DATABASE_URL="sqlite:///./test.db", STAFF_PASSWORD="s", ADMIN_PASSWORD="a",
                  WEBHOOK_SECRET="sec", WORKER_ENABLED="false", AUTO_ENABLE_NEW_GROUPS="false",
                  STAFF_USERS="ali:pw1", MEDIA_DIR=tempfile.mkdtemp())
if os.path.exists("test.db"): os.remove("test.db")

import pytest
from fastapi.testclient import TestClient
from app import main, worker, parser, waha
from app.db import SessionLocal, Message

ADMIN = {"Authorization": "Basic " + base64.b64encode(b"admin:a").decode()}
STAFF = {"Authorization": "Basic " + base64.b64encode(b"staff:s").decode()}
G1, G2, FAM = "120363001@g.us", "120363002@g.us", "120363999@g.us"
MSG = "🇭🇰 WTS\n126710BLNR 2024 full set hkd128k\n5711/1A 2019 used hkd1.05m"

FAKE = [
    {"direction": "WTS", "brand": "Rolex", "family": "GMT-Master II", "model": "Batman", "reference": "126710BLNR",
     "year": 2024, "set_type": "FULL_SET", "price": 128000, "currency": "HKD", "country": "HK",
     "source_text": "126710BLNR 2024 full set hkd128k"},
    {"direction": "WTS", "brand": "Patek Philippe", "family": "Nautilus", "reference": "5711/1A", "year": 2019,
     "condition": "USED", "price": 1050000, "currency": "hkd", "country": "hk", "source_text": "5711/1A 2019 used hkd1.05m"},
    {"direction": "WTS", "source_text": "garbage with no watch"},
]
calls = {"n": 0}

EXTRA = {}

async def fake_extract(text, group_name=None, client=None):
    calls["n"] += 1
    if text in EXTRA:
        return EXTRA[text]
    return FAKE if "126710" in text else [{"direction": "WTB", "brand": "Rolex", "reference": "126500LN",
                                           "family": "Daytona", "source_text": text}]

def payload(i, chat, body, sender="447700900001@s.whatsapp.net", name="Ali HK", ts=None, photo=False):
    p = {"event": "message", "session": "default", "payload": {
        "id": f"false_{chat}_{i}", "timestamp": ts or int(time.time()), "from": chat, "fromMe": False,
        "participant": sender, "body": body, "hasMedia": photo, "_data": {"pushName": name}}}
    if photo:
        p["payload"]["media"] = {"url": f"http://localhost:3000/api/files/default/{i}.jpeg", "mimetype": "image/jpeg"}
    return p

@pytest.fixture(scope="module")
def client():
    parser_orig = worker.extract_offers
    worker.extract_offers = fake_extract
    async def fake_groups():
        return [{"id": G1, "name": "HK Dealers", "participants": 200},
                {"id": G2, "name": "Dubai Watches", "participants": 90},
                {"id": FAM, "name": "Family", "participants": 8}]
    waha.list_groups = fake_groups
    async def fake_hist(chat_id, limit=300, **kw):
        return [payload(100, chat_id, "WTB 126500LN panda any year")["payload"],
                payload(101, chat_id, "thanks bro")["payload"],
                {"id": "x", "from": "447@c.us", "body": "private"}]
    waha.chat_messages = fake_hist
    with TestClient(main.app) as c:
        yield c
    worker.extract_offers = parser_orig

def test_auth(client):
    assert client.get("/").status_code == 401
    assert client.get("/", headers=STAFF).status_code == 200
    assert client.get("/admin", headers=STAFF).status_code == 401
    assert client.get("/admin", headers=ADMIN).status_code == 200
    assert client.post("/webhook/waha?token=bad", json={}).status_code == 403

def test_groups_sync_and_toggle(client):
    r = client.post("/admin/api/groups/sync", headers=ADMIN).json()
    assert r == {"found": 3, "added": 3}
    gs = client.get("/admin/api/groups", headers=ADMIN).json()
    assert all(not g["enabled"] for g in gs)
    client.post("/admin/api/groups/toggle", headers=ADMIN, json={"ids": [G1, G2], "enabled": True})
    gs = {g["id"]: g for g in client.get("/admin/api/groups", headers=ADMIN).json()}
    assert gs[G1]["enabled"] and gs[G2]["enabled"] and not gs[FAM]["enabled"]

def test_webhook_filters(client):
    ok = lambda p: client.post("/webhook/waha?token=sec", json=p).json()
    assert ok(payload(1, G1, MSG))["stored"] is True
    assert ok(payload(1, G1, MSG)).get("stored") is False          # duplicate id
    assert ok(payload(2, FAM, "WTS 126710BLNR hkd128k")).get("stored") is False  # disabled group
    assert "stored" not in ok(payload(3, "447700900002@s.whatsapp.net", "private WTS 126710"))  # DM ignored
    assert ok(payload(4, G2, MSG, sender="447700900001@s.whatsapp.net"))["stored"]  # same text other group
    assert ok(payload(5, G2, "ok 👍"))["stored"]
    with SessionLocal() as s:
        assert s.query(Message).count() == 3

def test_worker_parses_dedupes_and_caches(client):
    calls["n"] = 0
    n, err = asyncio.run(worker.process_batch())
    assert (n, err) == (3, 0)
    assert calls["n"] == 1  # same text in 2 groups -> parsed once, "ok" skipped by prefilter
    with SessionLocal() as s:
        st = {m.text[:5]: m.status for m in s.query(Message)}
    assert st["ok 👍"] == "SKIPPED"
    d = client.get("/api/offers", headers=STAFF).json()
    assert d["total"] == 2  # garbage dropped; cross-group repost merged
    by = {o["reference"]: o for o in d["items"]}
    gmt = by["126710BLNR"]
    assert gmt["seen_count"] == 2 and sorted(gmt["groups"]) == ["Dubai Watches", "HK Dealers"]
    assert gmt["dealer_phone"] == "447700900001" and gmt["dealer_name"] == "Ali HK"
    assert gmt["currency"] == "HKD" and 10000 < gmt["price_base"] < 15000
    assert by["5711/1A"]["country"] == "HK" and by["5711/1A"]["condition"] == "USED"

def test_search_filters(client):
    q = lambda **p: client.get("/api/offers", headers=STAFF, params=p).json()["total"]
    assert q(q="126710 blnr") == 1
    assert q(q="126710-BLNR") == 1
    assert q(q="nautilus") == 1
    assert q(direction="WTB") == 0
    assert q(max_price=20000) == 1
    assert q(condition="USED") == 1
    assert q(set_type="FULL_SET") == 1
    assert q(group=G2) == 1
    assert q(sort="price", order="asc")== 2
    f = client.get("/api/facets", headers=STAFF).json()
    assert set(f["brands"]) == {"Rolex", "Patek Philippe"} and f["countries"] == ["HK"]
    oid = client.get("/api/offers", headers=STAFF).json()["items"][0]["id"]
    assert "126710BLNR" in client.get(f"/api/offers/{oid}", headers=STAFF).json()["original_message"]

def test_backfill(client):
    r = client.post("/admin/api/groups/backfill", headers=ADMIN, json={"group_id": G1}).json()
    assert r == {"fetched": 3, "stored": 2}
    assert client.post("/admin/api/groups/backfill", headers=ADMIN, json={"group_id": FAM}).status_code == 400
    asyncio.run(worker.process_batch())
    assert client.get("/api/offers", headers=STAFF, params={"direction": "WTB"}).json()["total"] == 1
    s = client.get("/admin/api/stats", headers=ADMIN).json()
    assert s["messages_by_status"]["SKIPPED"] == 2 and s["offers_total"] == 3

def test_prefilter():
    yes = ["WTB 126500LN", "5711 hkd 1.2m", "RM 67-01 available", "AP 15510 blue fs", "Daytona panda new card 180k"]
    no = ["ok", "thanks bro 🙏", "good morning all", "who is in HK next week?", "😂😂"]
    assert all(parser.looks_like_offer(t) for t in yes), [t for t in yes if not parser.looks_like_offer(t)]
    assert not any(parser.looks_like_offer(t) for t in no), [t for t in no if parser.looks_like_offer(t)]

def test_normalize_variants():
    from app.ingest import normalize
    lid = {"id": "a", "from": G1, "body": "x", "participant": "123@lid",
           "_data": {"key": {"participantAlt": "447700900009@s.whatsapp.net"}, "pushName": "Z"}}
    assert normalize(lid)["sender_phone"] == "447700900009"
    mine = {"id": "b", "from": "447@s.whatsapp.net", "to": G1, "fromMe": True, "body": "WTS"}
    assert normalize(mine)["group_id"] == G1
    assert normalize({"id": "c", "from": G1, "body": ""}) is None

def test_advisor(client):
    from app.db import Offer
    from app.db import utcnow
    import datetime as dt
    with SessionLocal() as s:
        for i, p in enumerate([13000, 13400, 13800, 14200, 14600, 1400]):
            s.add(Offer(message_id=1, group_id=G1, groups_seen=G1, direction="WTS", brand="Rolex",
                        reference="126710BLNR", reference_norm="126710BLNR", condition="NEW", set_type="FULL_SET",
                        year=2023, price=p, currency="GBP", price_base=p, country="GB", dealer_phone=f"44{i}",
                        fingerprint=f"adv{i}", first_seen_at=utcnow(), last_seen_at=utcnow() - dt.timedelta(days=i)))
        s.add(Offer(message_id=1, group_id=G1, groups_seen=G1, direction="WTB", reference="126710BLNR",
                    reference_norm="126710BLNR", dealer_phone="449", fingerprint="advb",
                    first_seen_at=utcnow(), last_seen_at=utcnow()))
        s.commit()
    r = client.post("/api/advise", headers=STAFF, json={"reference": "126710-blnr", "condition": "USED",
                                                         "set_type": "WATCH_ONLY", "asking_price": 20000}).json()
    assert r["watch"]["family"] == "GMT-Master II"
    assert r["comparables"] >= 5 and r["market_low"] > 5000          # £1,400 typo trimmed
    assert r["offer"] < r["max_price"] < r["quick_resale"] < 13000     # used + watch only < full set new asks
    assert r["asking"]["code"] == "WALK_AWAY"
    assert client.post("/api/advise", headers=STAFF, json={"reference": "99999"}).json()["verdict"] == "NO_DATA"
    assert client.post("/api/advise", json={"reference": "x"}).status_code == 401


# ====================================================================== new features
import io
import httpx as _httpx
from PIL import Image
from app import alerts as alerts_mod, media as media_mod
from app.db import Offer as _Offer, utcnow as _now

_buf = io.BytesIO(); Image.new("RGB", (800, 600), (30, 90, 60)).save(_buf, "PNG"); PNG = _buf.getvalue()
SENT = []


class _FakeHttpx:
    @staticmethod
    def AsyncClient(**kw):
        return _httpx.AsyncClient(transport=_httpx.MockTransport(lambda r: _httpx.Response(200, content=PNG)))


@pytest.fixture(autouse=True, scope="module")
def _patches():
    media_mod.httpx = _FakeHttpx
    async def tg(text, photo_path=None, chat_id=None):
        SENT.append(text); return True
    alerts_mod.send_telegram = tg
    yield


ALI = {"Authorization": "Basic " + base64.b64encode(b"ali:pw1").decode()}
REF_OFFER = lambda price, **k: [{"direction": "WTS", "brand": "Rolex", "family": "Submariner", "reference": "124060",
                                 "condition": "NEW", "set_type": "FULL_SET", "year": 2024, "price": price,
                                 "currency": "GBP", "source_text": f"124060 {price}", **k}]


def test_named_staff_login(client):
    assert client.get("/api/me", headers=ALI).json()["user"] == "ali"
    assert client.get("/api/me", headers={"Authorization": "Basic " + base64.b64encode(b"ali:bad").decode()}).status_code == 401


def test_market_comps_then_deal_alert_and_photo(client):
    # 5 other dealers asking ~£10,500 for 124060 -> market
    with SessionLocal() as s:
        for i, p in enumerate([10300, 10400, 10500, 10600, 10700]):
            s.add(_Offer(message_id=1, group_id=G1, groups_seen=G1, direction="WTS", brand="Rolex", family="Submariner",
                         reference="124060", reference_norm="124060", condition="NEW", set_type="FULL_SET", year=2024,
                         price=p, currency="GBP", price_base=p, dealer_key=f"44990{i}", dealer_phone=f"44990{i}",
                         fingerprint=f"mk{i}", first_seen_at=_now(), last_seen_at=_now()))
        s.commit()
    # alert saved from the feed by ali
    r = client.post("/api/alerts", headers=ALI, json={"name": "Cheap Subs", "query": {"q": "124060", "max_price": 9500,
                                                                                         "period": "2w"}})
    aid = r.json()["id"]
    # dealer sends text, then a photo 20s later
    t0 = int(time.time())
    EXTRA["WTS 124060 2024 N FS £9,000"] = REF_OFFER(9000)
    client.post("/webhook/waha?token=sec", json=payload(300, G1, "WTS 124060 2024 N FS £9,000", ts=t0))
    r = client.post("/webhook/waha?token=sec", json=payload(301, G1, "", ts=t0 + 20, photo=True)).json()
    assert r["photo"] is True and r["stored"] is False
    # other dealer's photo in same group must not attach
    client.post("/webhook/waha?token=sec", json=payload(302, G1, "", ts=t0 + 10, photo=True, sender="447700900777@s.whatsapp.net"))
    SENT.clear()
    asyncio.run(worker.process_batch())
    d = client.get("/api/offers", headers=STAFF, params={"q": "124060", "deals_only": "true"}).json()
    assert d["total"] == 1
    o = d["items"][0]
    assert o["deal"] == "DEAL" and -0.16 < o["market_pct"] < -0.12
    assert o["photo_id"] and o["photo_kind"] == "EXACT"
    img = client.get(f"/media/{o['photo_id']}/thumb", headers=STAFF)
    assert img.status_code == 200 and img.headers["content-type"] == "image/jpeg"
    assert client.get(f"/media/{o['photo_id']}/thumb").status_code == 401
    assert any("Cheap Subs" in t and "124060" in t for t in SENT)
    a = [x for x in client.get("/api/alerts", headers=STAFF).json()["alerts"] if x["id"] == aid][0]
    assert a["hit_count"] == 1 and a["created_by"] == "ali" and "period" not in a["query"]
    assert client.get(f"/api/alerts/{aid}/matches", headers=STAFF).json()[0]["id"] == o["id"]
    # detail view has gallery + reference summary has history
    det = client.get(f"/api/offers/{o['id']}", headers=STAFF).json()
    assert det["photos"] == [o["photo_id"]]
    ref = client.get("/api/refs/124060", headers=STAFF).json()
    assert len(ref["history"]) == 26 and ref["history"][-1]["count"] >= 6 and ref["family"] == "Submariner"


def test_captioned_photo_and_reference_fallback(client):
    EXTRA["WTS 124060 2023 watch only 8,800"] = REF_OFFER(8800, set_type="WATCH_ONLY", year=2023)
    client.post("/webhook/waha?token=sec", json=payload(310, G2, "WTS 124060 2023 watch only 8,800", photo=True,
                                                         sender="447700900555@s.whatsapp.net", name="Bob"))
    asyncio.run(worker.process_batch())
    items = client.get("/api/offers", headers=STAFF, params={"q": "124060"}).json()["items"]
    bob = [i for i in items if i["dealer_name"] == "Bob"][0]
    assert bob["photo_kind"] == "EXACT"
    # comps inserted without photos fall back to the latest reference photo
    others = [i for i in items if i["dealer_key"] and i["dealer_key"].startswith("44990")]
    assert others and all(i["photo_kind"] == "REFERENCE" and i["photo_id"] for i in others)


def test_tracking_and_hide_handled(client):
    oid = client.get("/api/offers", headers=STAFF, params={"q": "124060", "deals_only": "true"}).json()["items"][0]["id"]
    r = client.post(f"/api/offers/{oid}/track", headers=ALI, json={"status": "contacted", "note": "offered 8.5k"}).json()
    assert r["status"] == "CONTACTED" and r["by"] == "ali"
    it = [i for i in client.get("/api/offers", headers=STAFF, params={"q": "124060"}).json()["items"] if i["id"] == oid][0]
    assert it["track"]["by"] == "ali" and it["track"]["note"] == "offered 8.5k"
    assert oid not in [i["id"] for i in client.get("/api/offers", headers=STAFF, params={"q": "124060", "hide_handled": "true"}).json()["items"]]
    assert client.post(f"/api/offers/{oid}/track", headers=ALI, json={"status": "bogus"}).status_code == 400


def test_dealers_rating_and_block(client):
    lst = client.get("/api/dealers", headers=STAFF).json()
    ali = [d for d in lst if d["key"] == "447700900001"][0]
    assert ali["listings"] >= 3 and ali["name"] == "Ali HK"
    before = client.get("/api/offers", headers=STAFF, params={"period": "all"}).json()["total"]
    assert client.put("/api/dealers/447700900001", headers=ALI, json={"rating": "BLOCKED", "note": "sold a fake"}).json()["ok"]
    prof = client.get("/api/dealers/447700900001", headers=STAFF).json()
    assert prof["rating"] == "BLOCKED" and prof["updated_by"] == "ali" and prof["recent"]
    after = client.get("/api/offers", headers=STAFF, params={"period": "all"}).json()["total"]
    assert after < before
    assert client.get("/api/offers", headers=STAFF, params={"period": "all", "show_blocked": "true"}).json()["total"] == before
    client.put("/api/dealers/447700900001", headers=ALI, json={"rating": "TRUSTED", "note": "ok now"})
    it = client.get("/api/offers", headers=STAFF, params={"q": "126710"}).json()["items"][0]
    assert it["dealer_rating"] == "TRUSTED"


def test_stock_matching_and_notification(client):
    r = client.post("/api/stock", headers=ALI, json={"reference": "126500 LN", "description": "Daytona white",
                                                     "condition": "new", "set_type": "full set", "asking_price": 24000})
    sid = r.json()["id"]
    SENT.clear()
    client.post("/webhook/waha?token=sec", json=payload(320, G2, "WTB 126500LN any year cash", sender="447700900888@s.whatsapp.net", name="Buyer"))
    asyncio.run(worker.process_batch())
    assert any("📦" in t for t in SENT)
    st = client.get("/api/stock", headers=STAFF).json()["items"]
    item = [i for i in st if i["id"] == sid][0]
    assert item["reference_norm"] == "126500LN" and item["condition"] == "NEW" and item["set_type"] == "FULL_SET"
    assert item["wtb_dealers_30d"] >= 1
    assert client.get(f"/api/stock/{sid}/matches", headers=STAFF).json()[0]["direction"] == "WTB"
    wtb = client.get("/api/offers", headers=STAFF, params={"direction": "WTB", "q": "126500"}).json()["items"]
    assert wtb and all(w["in_stock"] for w in wtb)
    imp = client.post("/api/stock/import", headers=ALI, json={"csv": "reference,description,condition,set_type,year,asking_price\n"
                      "5711/1A-010,Nautilus,used,full set,2019,\"98,000\"\n,missing ref,,,,\n"}).json()
    assert imp["added"] == 1 and len(imp["skipped"]) == 1
    client.put(f"/api/stock/{sid}", headers=ALI, json={"reference": "126500LN", "status": "SOLD"})
    assert sid not in [i["id"] for i in client.get("/api/stock", headers=STAFF).json()["items"]]


def test_digest_and_pages(client):
    d = client.get("/api/digest/preview", headers=STAFF).json()
    assert "Watch market summary" in d["text"] and d["data"]["new_offers"] >= 1
    for page in ("/", "/advisor", "/alerts", "/dealers", "/stock"):
        assert client.get(page, headers=ALI).status_code == 200
    assert client.get("/static/common.js").status_code == 200
    assert client.post("/api/notify/test", headers=STAFF).status_code == 401
