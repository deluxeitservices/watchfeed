"""AI extraction of WTS / WTB watch offers from raw WhatsApp dealer messages."""
import asyncio
import hashlib
import logging
import re
from typing import Optional

import httpx

from .config import settings

log = logging.getLogger("parser")

# ---------------------------------------------------------------- prefilter (free, runs before the AI)
# Words that only appear in watch trading
_WATCH = re.compile(
    r"\b(wts|wtb|ltb|lnib|bnib|unworn|full ?set|b ?& ?p|warranty card|"
    r"rolex|patek|pp|audemars|ap|richard ?mille|rm ?\d|vacheron|vc|cartier|omega|tudor|"
    r"iwc|breitling|hublot|panerai|jlc|jaeger|lange|journe|mb&f|tag heuer|zenith|grand seiko|"
    r"daytona|submariner|sub|gmt|datejust|dj ?\d*|day-?date|yacht-?master|explorer|sea-?dweller|sky-?dweller|"
    r"nautilus|aquanaut|royal ?oak|offshore|overseas|santos|panthere|speedmaster|seamaster|"
    r"batman|batgirl|pepsi|sprite|hulk|kermit|panda|jubilee|oyster|president|bezel|dial|chrono(?:graph)?)\b",
    re.I,
)
# Reference-number shapes: 126710BLNR, 116500, 5711/1A, 5167A, 15500ST, IW371446, WSSA0018, RM 67-01
_STRONG_REF = re.compile(
    r"\b\d{5,6}[a-z]{0,6}\b|\b\d{4}(?:/\d?[a-z]{1,3}|[a-z]{1,5})\b|\b[a-z]{2,4}\d{4,}[a-z0-9]*\b|\brm\s?\d{2,3}[-‐]\d{2}\b",
    re.I,
)
_TRADE = re.compile(r"\b(sell|selling|buy|buying|looking|need|wanted|available|avail|stock|net|price|offer|new|used|mint)\b", re.I)
_PRICE = re.compile(r"[$£€¥]|\d+(?:[.,]\d+)?\s?[km]\b|\b\d{1,3}(?:[,.]\d{3})+\b|\b(hkd|usd|usdt|aed|eur|gbp|chf|sgd|dhs)\b", re.I)
_WEAK_REF = re.compile(r"\b\d{4}\b")
_CURRENCY = re.compile(r"\b(hkd|usd|usdt|aed|eur|chf|sgd|dhs|hk\$|u\$)|\d+(?:[.,]\d+)?\s?[km]\b", re.I)
# Common non-watch ads in mixed groups
_NEGATIVE = re.compile(
    r"\b(room|rooms|rent|bedroom|flat|studio|landlord|deposit|pcm|licen[cs]e|driving|theory|visa|"
    r"delivery accounts?|uber|deliveroo|job|vacancy|hiring|loan|mortgage|insurance|course|tutor)\b",
    re.I,
)


def looks_like_offer(text: str) -> bool:
    """True if a message is worth sending to the AI. Free, so it's deliberately strict."""
    t = (text or "").strip()
    if len(t) < 5:
        return False
    watch = bool(_WATCH.search(t))
    ref = bool(_STRONG_REF.search(t))
    if _NEGATIVE.search(t) and not watch:
        return False
    if not (watch or ref):
        # bare 4-digit references (5711, 5167) only count next to a trade currency: "5711 hkd 1.2m"
        return bool(_WEAK_REF.search(t) and _CURRENCY.search(t))
    return ref or bool(_PRICE.search(t)) or bool(_TRADE.search(t))


def text_hash(text: str) -> str:
    norm = re.sub(r"\s+", " ", (text or "").strip().lower())
    return hashlib.sha256(norm.encode()).hexdigest()


# ---------------------------------------------------------------- LLM
SYSTEM_PROMPT = """Extract watch trade offers from WhatsApp messages in grey-market luxury watch dealer groups.
You get several numbered messages; each line is prefixed with its line number (L1, L2...). Call record_offers once.

One offer per distinct watch line (a 30-line price list = 30 offers). Chat, greetings, questions, shipping talk, \
non-watch items (jewellery, bags, rooms, services) = no offers.

dir: WTB if "wtb/looking for/LF/need/searching/buying/who has", else WTS (lists with prices, "available", "in stock").
brand: canonical (Rolex, Patek Philippe, Audemars Piguet, Richard Mille, Vacheron Constantin, Cartier, Omega, Tudor, \
A. Lange & Söhne, F.P. Journe, IWC, Jaeger-LeCoultre, Hublot, Panerai, Breitling). AP=Audemars Piguet, PP=Patek, \
RM=Richard Mille, VC=Vacheron. Infer from reference when clear.
fam: collection (Daytona, Submariner, GMT-Master II, Datejust, Day-Date, Nautilus, Aquanaut, Royal Oak, Offshore...). \
model: nickname if given (Batman, Pepsi, Panda, Hulk). ref: reference as written, cleaned; never invent.
dial, case (stainless steel/yellow gold/rose gold/white gold/platinum/titanium/two-tone), brace (Oyster/Jubilee/rubber...).
dia: true only if diamond dial/markers stated.
cond: N (new/unworn/BNIB/sticker/NOS), L (LNIB/like new/mint), U (used/pre-owned/polished), V (vintage, pre-1990).
set: F (full set/FS/B&P), W (watch only/naked), B (watch+box, no papers), P (watch+papers/card, no box).
yr/mo: card date ("23y"=2023, "03/2024", "new card"=current year).
price: full number ("hkd541k"=541000, "$23.5k"=23500, "1.2m"=1200000). Never guess. \
disc: % vs retail when only that is given ("-12%" = -12). cur: ISO (USD HKD EUR GBP AED CHF SGD JPY CNY USDT); \
"$" = USD unless Hong Kong context with large amounts (then HKD). "k" is a multiplier, not a currency.
cc: ISO-2 location from flags/cities (🇭🇰 HK, 🇦🇪/Dubai AE, 🇬🇧/London GB, 🇺🇸 US, 🇨🇭 CH, 🇸🇬 SG). note: short extra info.
m: message number. l: the line number(s) of that offer.

Header/footer lines on their own (brand, flag, "all HKD", "all full set", "all 2024") apply to lines under them. \
Condition/set/year written on one watch's line belong to that line only.
OMIT every field you don't know. Never output null, empty strings or false."""

_S = {"type": "string"}
OFFER_TOOL = {
    "name": "record_offers",
    "description": "Record every watch offer found in the messages (empty list if none). Omit unknown fields.",
    "input_schema": {
        "type": "object",
        "properties": {
            "offers": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "m": {"type": "integer"}, "l": {"type": "array", "items": {"type": "integer"}},
                        "dir": {"type": "string", "enum": ["WTS", "WTB"]},
                        "brand": _S, "fam": _S, "model": _S, "ref": _S, "dial": _S, "case": _S, "brace": _S,
                        "dia": {"type": "boolean"},
                        "cond": {"type": "string", "enum": ["N", "L", "U", "V"]},
                        "set": {"type": "string", "enum": ["F", "W", "B", "P"]},
                        "yr": {"type": "integer"}, "mo": {"type": "integer"},
                        "price": {"type": "number"}, "cur": _S, "disc": {"type": "number"},
                        "cc": _S, "city": _S, "note": _S,
                    },
                    "required": ["m", "l", "dir"],
                },
            }
        },
        "required": ["offers"],
    },
}
_COND = {"N": "NEW", "L": "LIKE_NEW", "U": "USED", "V": "VINTAGE"}
_SET = {"F": "FULL_SET", "W": "WATCH_ONLY", "B": "BOX_ONLY", "P": "PAPERS_ONLY"}

API_URL = "https://api.anthropic.com/v1/messages"


class ParseError(Exception):
    pass


def _numbered(text: str) -> tuple:
    lines = text[:settings.MAX_MESSAGE_CHARS].splitlines()
    return lines, "\n".join(f"L{i}: {ln}" for i, ln in enumerate(lines, 1) if ln.strip())


def expand(o: dict, lines: list) -> dict:
    """Compact AI output -> the full offer dict the rest of the app uses."""
    src = [lines[i - 1] for i in (o.get("l") or []) if isinstance(i, int) and 1 <= i <= len(lines)]
    return {"direction": o.get("dir", "WTS"), "brand": o.get("brand"), "family": o.get("fam"), "model": o.get("model"),
            "reference": o.get("ref"), "dial_color": o.get("dial"), "case_material": o.get("case"),
            "bracelet": o.get("brace"), "diamond_indices": bool(o.get("dia")),
            "condition": _COND.get(o.get("cond")), "set_type": _SET.get(o.get("set")),
            "year": o.get("yr"), "month": o.get("mo"), "price": o.get("price"), "currency": o.get("cur"),
            "discount_pct": o.get("disc"), "country": o.get("cc"), "city": o.get("city"), "notes": o.get("note"),
            "source_text": "\n".join(x.strip() for x in src), "_lines": o.get("l") or []}


async def _call(body: dict, client: httpx.AsyncClient) -> dict:
    headers = {"x-api-key": settings.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01",
               "content-type": "application/json"}
    for attempt in range(5):
        try:
            r = await client.post(API_URL, json=body, headers=headers)
        except httpx.TransportError as e:
            log.warning("LLM transport error: %s", e)
            await asyncio.sleep(3 * 2 ** attempt)
            continue
        if r.status_code in (429, 500, 502, 503, 504, 529):
            wait = float(r.headers.get("retry-after") or 3 * 2 ** attempt)
            log.warning("LLM %s, retrying in %.0fs", r.status_code, wait)
            await asyncio.sleep(min(wait, 60))
            continue
        if r.status_code >= 400:
            raise ParseError(f"LLM HTTP {r.status_code}: {r.text[:300]}")
        return r.json()
    raise ParseError("LLM unavailable after retries")


async def extract_batch(items: list, client: Optional[httpx.AsyncClient] = None) -> tuple:
    """items: [(text, group_name)]. One AI call for all of them.
    Returns ([offers_for_item_0, offers_for_item_1, ...], {"input_tokens": n, "output_tokens": n}).
    Raises ParseError('too long') if the answer didn't fit - caller should split the batch."""
    if not settings.ANTHROPIC_API_KEY:
        raise ParseError("ANTHROPIC_API_KEY not set")
    blocks, all_lines = [], []
    for i, (text, group) in enumerate(items, 1):
        lines, numbered = _numbered(text)
        all_lines.append(lines)
        blocks.append(f"=== Message {i} (group: {group or 'unknown'}) ===\n{numbered}")
    body = {
        "model": settings.ANTHROPIC_MODEL,
        "max_tokens": 8192,
        "system": SYSTEM_PROMPT,
        "tools": [OFFER_TOOL],
        "tool_choice": {"type": "tool", "name": "record_offers"},
        "messages": [{"role": "user", "content": "\n\n".join(blocks)}],
    }
    own = client is None
    client = client or httpx.AsyncClient(timeout=180)
    try:
        data = await _call(body, client)
    finally:
        if own:
            await client.aclose()
    usage = data.get("usage") or {}
    usage = {"input_tokens": usage.get("input_tokens", 0), "output_tokens": usage.get("output_tokens", 0)}
    if data.get("stop_reason") == "max_tokens":
        raise ParseError("too long")
    raw = []
    for block in data.get("content", []):
        if block.get("type") == "tool_use":
            raw = block.get("input", {}).get("offers", []) or []
    out = [[] for _ in items]
    for o in raw if isinstance(raw, list) else []:
        m = o.get("m") if isinstance(o, dict) else None
        if not isinstance(m, int) or not 1 <= m <= len(items):
            m = 1 if len(items) == 1 else None
        if m:
            out[m - 1].append(expand(o, all_lines[m - 1]))
    return out, usage


async def extract_offers(text: str, group_name: Optional[str] = None,
                         client: Optional[httpx.AsyncClient] = None) -> list:
    """Single message (Buy Advisor, try_parse)."""
    res, _ = await extract_batch([(text, group_name)], client)
    return res[0]
