"""Background loop: parse NEW messages into offers."""
import asyncio
import hashlib
import json
import logging
from datetime import timedelta
from typing import Optional

import httpx
from sqlalchemy import select

from . import alerts, cost, fx, market, media, refs
from .config import settings
from .db import AiUsage, Group, LineCache, Message, Offer, ParseCache, SessionLocal, utcnow
from .parser import ParseError, extract_batch, looks_like_offer

log = logging.getLogger("worker")

CONDITIONS = {"NEW", "LIKE_NEW", "USED", "VINTAGE"}
SET_TYPES = {"FULL_SET", "WATCH_ONLY", "BOX_ONLY", "PAPERS_ONLY"}


from .worker_utils import norm_ref  # noqa: E402,F401  (re-exported)


def _s(v, n=200) -> Optional[str]:
    if v is None:
        return None
    v = str(v).strip()
    return v[:n] or None


def clean_offer(o: dict) -> Optional[dict]:
    if not isinstance(o, dict):
        return None
    direction = str(o.get("direction") or "WTS").upper()
    if direction not in ("WTS", "WTB"):
        direction = "WTS"
    brand, ref = _s(o.get("brand"), 80), _s(o.get("reference"), 80)
    family, model = _s(o.get("family"), 120), _s(o.get("model"), 200)
    if not (brand or ref or family or model):
        return None
    year = o.get("year")
    try:
        year = int(year) if year is not None else None
        if year is not None and year < 100:
            year += 2000
        if year is not None and not (1900 <= year <= utcnow().year + 1):
            year = None
    except (TypeError, ValueError):
        year = None
    month = o.get("month")
    try:
        month = int(month) if month is not None and 1 <= int(month) <= 12 else None
    except (TypeError, ValueError):
        month = None
    try:
        price = float(o["price"]) if o.get("price") not in (None, "") else None
        if price is not None and price <= 0:
            price = None
    except (TypeError, ValueError):
        price = None
    currency = fx.normalize_currency(o.get("currency")) if price is not None else None
    try:
        disc = float(o["discount_pct"]) if o.get("discount_pct") is not None else None
    except (TypeError, ValueError):
        disc = None
    cond = str(o.get("condition") or "").upper() or None
    st = str(o.get("set_type") or "").upper() or None
    country = str(o.get("country") or "").upper()[:2] or None
    known_brand, known_family = refs.lookup(norm_ref(ref), brand)
    if known_family:
        brand, family = known_brand, known_family
    return {
        "direction": direction, "brand": brand, "family": family, "model": model,
        "reference": ref, "reference_norm": norm_ref(ref),
        "dial_color": _s(o.get("dial_color"), 80), "case_material": _s(o.get("case_material"), 80),
        "bracelet": _s(o.get("bracelet"), 80), "diamond_indices": bool(o.get("diamond_indices")),
        "condition": cond if cond in CONDITIONS else None,
        "set_type": st if st in SET_TYPES else None,
        "year": year, "month": month, "price": price, "currency": currency,
        "price_base": fx.to_base(price, currency), "discount_pct": disc,
        "country": country if country and country.isalpha() else None,
        "city": _s(o.get("city"), 80), "notes": _s(o.get("notes"), 500),
        "source_text": (_s(o.get("source_text"), 2000) or ""),
    }


def fingerprint(o: dict, dealer: str) -> str:
    parts = [o["direction"], o["reference_norm"] or (o["brand"] or "") + (o["model"] or ""),
             o["dial_color"] or "", str(o["price"] or ""), o["currency"] or "",
             o["condition"] or "", o["set_type"] or "", str(o["year"] or ""), dealer]
    return hashlib.sha1("|".join(p.lower() for p in parts).encode()).hexdigest()


def compute_market_pct(s, o: dict, dealer_key: str, ts) -> Optional[float]:
    if o["direction"] != "WTS" or not o["price_base"] or not o["reference_norm"]:
        return None
    rows = s.execute(select(Offer.price_base, Offer.condition, Offer.set_type).where(
        Offer.reference_norm == o["reference_norm"], Offer.direction == "WTS", Offer.price_base.is_not(None),
        Offer.last_seen_at >= ts - timedelta(days=30), Offer.dealer_key != dealer_key)).all()
    comps = [market.normalize(p, c, st) for p, c, st in rows]
    return market.market_pct(market.normalize(o["price_base"], o["condition"], o["set_type"]), comps)


def save_offers(s, msg: Message, raw_offers: list) -> tuple:
    """Returns (offers_found, [newly created Offer rows])."""
    dealer_key = media.sender_key(msg.sender_phone, msg.sender_name) or ""
    window = msg.ts - timedelta(days=settings.DUPLICATE_WINDOW_DAYS)
    count, new, touched = 0, [], []
    for raw in raw_offers:
        o = clean_offer(raw)
        if not o:
            continue
        fp = fingerprint(o, dealer_key)
        existing = s.scalar(select(Offer).where(Offer.fingerprint == fp, Offer.last_seen_at >= window)
                            .order_by(Offer.last_seen_at.desc()).limit(1))
        if existing:
            existing.duplicate_count += 1
            if msg.ts > existing.last_seen_at:
                existing.last_seen_at = msg.ts
            if msg.ts < existing.first_seen_at:
                existing.first_seen_at = msg.ts
            seen = set(filter(None, existing.groups_seen.split(",")))
            seen.add(msg.group_id)
            existing.groups_seen = ",".join(sorted(seen))
            touched.append(existing)
        else:
            row = Offer(message_id=msg.id, group_id=msg.group_id, groups_seen=msg.group_id,
                        dealer_name=msg.sender_name, dealer_phone=msg.sender_phone, dealer_key=dealer_key or None,
                        market_pct=compute_market_pct(s, o, dealer_key, msg.ts),
                        fingerprint=fp, first_seen_at=msg.ts, last_seen_at=msg.ts, **o)
            s.add(row)
            new.append(row)
            touched.append(row)
        count += 1
    if touched:
        s.flush()
        media.link_for_message(s, msg, touched)
    return count, new


# ---------------------------------------------------------------- budget
def record_usage(s, usage: dict) -> None:
    day = utcnow().strftime("%Y-%m-%d")
    row = s.get(AiUsage, day)
    if row is None:
        row = AiUsage(day=day, tokens_in=0, tokens_out=0, calls=0)
        s.add(row)
    row.tokens_in = (row.tokens_in or 0) + usage.get("input_tokens", 0)
    row.tokens_out = (row.tokens_out or 0) + usage.get("output_tokens", 0)
    row.calls = (row.calls or 0) + 1


def spend(s) -> dict:
    """USD spent today and this month (UTC)."""
    today = utcnow().strftime("%Y-%m-%d")
    rows = s.scalars(select(AiUsage).where(AiUsage.day >= today[:8] + "01")).all()
    f = lambda r: cost.usd(r.tokens_in, r.tokens_out, settings.PRICE_IN_PER_M, settings.PRICE_OUT_PER_M)  # noqa: E731
    return {"today": sum(f(r) for r in rows if r.day == today), "month": sum(f(r) for r in rows),
            "calls_today": sum(r.calls or 0 for r in rows if r.day == today)}


def budget_left(s) -> float:
    sp = spend(s)
    daily = cost.daily_limit(settings.AI_MONTHLY_BUDGET_USD, settings.AI_DAILY_BUDGET_USD)
    return min(daily - sp["today"], settings.AI_MONTHLY_BUDGET_USD - sp["month"])


# ---------------------------------------------------------------- AI calls
TRANSIENT = ("unavailable", "HTTP 5", "HTTP 429", "HTTP 529", "transport")


async def _call_batch(batch: list, names: dict, client) -> dict:
    """batch: [(key, Item, group_id)] -> {key: ("OK", offers, tin, tout) | ("ERROR", msg, transient)}.
    Never retries a paid call; only splits when an answer was too long (rare with line caps)."""
    try:
        res, usage = await extract_batch([(it.text, names.get(gid, "")) for _, it, gid in batch], client)
    except ParseError as e:
        if str(e) == "too long" and len(batch) > 1:
            half = len(batch) // 2
            return {**(await _call_batch(batch[:half], names, client)), **(await _call_batch(batch[half:], names, client))}
        return {k: ("ERROR", str(e), any(t in str(e) for t in TRANSIENT)) for k, _, _ in batch}
    except Exception as e:  # noqa: BLE001
        log.exception("AI batch failed")
        return {k: ("ERROR", repr(e), False) for k, _, _ in batch}
    with SessionLocal() as s:
        record_usage(s, usage)
        s.commit()
    total = sum(len(it.text) for _, it, _ in batch) or 1
    return {k: ("OK", offers, round(usage["input_tokens"] * len(it.text) / total),
                round(usage["output_tokens"] * len(it.text) / total))
            for (k, it, _), offers in zip(batch, res)}


async def process_batch(limit: int = 60) -> tuple:
    """Returns (processed, errors). Newest messages first, so live listings win when the budget is tight."""
    with SessionLocal() as s:
        msgs = s.scalars(select(Message).where(Message.status == "NEW")
                         .order_by(Message.ts.desc()).limit(limit)).all()
        groups = {g.id: g for g in s.scalars(select(Group)).all()}
    if not msgs:
        return 0, 0
    names = {k: g.name for k, g in groups.items()}
    oldest_ok = utcnow() - timedelta(hours=settings.AI_MAX_AGE_HOURS)
    results = {}   # text_hash -> (status, offers|error, tin, tout[, transient])
    work = {}      # text_hash -> (msg, plan, {cand_index: offers from cache})
    for m in msgs:
        h = m.text_hash
        if h in results or h in work:
            continue
        g = groups.get(m.group_id)
        if not looks_like_offer(m.text):
            results[h] = ("SKIPPED", None, 0, 0)
        elif g is not None and g.ai_paused:
            results[h] = ("PAUSED", None, 0, 0)
        else:
            with SessionLocal() as s:
                cached = s.get(ParseCache, h)
                if cached:
                    results[h] = ("OK", json.loads(cached.result_json), 0, 0)
                    continue
                p = cost.plan(m.text)
                hits = {r.key: json.loads(r.offers_json) for r in
                        s.scalars(select(LineCache).where(LineCache.key.in_(list(p.keys.values())))).all()} if p.keys else {}
            have = {i: hits[k] for i, k in p.keys.items() if k in hits}
            if len(have) == len(p.cand):          # every watch line seen before -> free
                results[h] = ("OK", [o for i in p.cand for o in have[i]], 0, 0)
            elif m.ts < oldest_ok:                 # history import: store, don't pay for it
                results[h] = ("OLD", None, 0, 0)
            else:
                work[h] = (m, p, have)

    if work:
        items = []
        for h, (m, p, have) in work.items():
            todo = [i for i in p.cand if i not in have]
            for n, it in enumerate(cost.make_items(p, todo, settings.AI_MAX_LINES_PER_CALL)):
                items.append(((h, n), it, m.group_id))
        calls = cost.batches([((k, g), it) for k, it, g in items], settings.AI_MAX_LINES_PER_CALL, settings.AI_BATCH_SIZE)
        answers = {}
        async with httpx.AsyncClient(timeout=180) as client:
            for i in range(0, len(calls), max(1, settings.LLM_CONCURRENCY)):
                with SessionLocal() as s:
                    if budget_left(s) <= 0:
                        log.warning("AI budget reached - remaining messages skipped")
                        break
                wave = calls[i:i + settings.LLM_CONCURRENCY]
                parts = await asyncio.gather(*[_call_batch([(k, it, g) for (k, g), it in c], names, client) for c in wave])
                for part in parts:
                    answers.update(part)
        with SessionLocal() as s:
            for h, (m, p, have) in work.items():
                mine = [(k, it) for k, it, _ in items if k[0] == h]
                got = [answers.get(k) for k, _ in mine]
                per_line, loose, tin, tout = dict(have), [], 0, 0
                for (k, it), a in zip(mine, got):   # remember every paid-for piece, even if another piece failed
                    if not a or a[0] != "OK":
                        continue
                    lines_map, extra = cost.assign(p, it, a[1])
                    for idx, offs in lines_map.items():
                        per_line[idx] = offs
                        if not s.get(LineCache, p.keys[idx]):
                            s.add(LineCache(key=p.keys[idx], offers_json=json.dumps(offs)))
                    loose += extra
                    tin, tout = tin + a[2], tout + a[3]
                if any(a is None for a in got):
                    results[h] = ("BUDGET", None, tin, tout)
                    continue
                errs = [a for a in got if a[0] == "ERROR"]
                if errs:
                    results[h] = ("ERROR", errs[0][1], tin, tout, all(e[2] for e in errs))
                    continue
                offers = [o for i in p.cand for o in per_line.get(i, [])] + loose
                results[h] = ("OK", offers, tin, tout)
                if not s.get(ParseCache, h):
                    s.add(ParseCache(text_hash=h, result_json=json.dumps(offers)))
            s.commit()

    errors, new_ids, billed = 0, [], set()
    with SessionLocal() as s:
        for m in msgs:
            r = results[m.text_hash]
            status, data, tin, tout = r[:4]
            msg, created = s.get(Message, m.id), []
            if m.text_hash not in billed:  # tokens counted once per unique text
                msg.tokens_in, msg.tokens_out = tin, tout
                billed.add(m.text_hash)
            if status in ("SKIPPED", "PAUSED", "OLD", "BUDGET"):
                msg.status = status
            elif status == "ERROR":
                errors += 1
                msg.attempts += 1
                msg.error = (data or "")[:1000]
                if msg.attempts >= 3 or not (len(r) > 4 and r[4]):  # only free/transient failures are retried
                    msg.status = "ERROR"
            else:
                n, created = save_offers(s, msg, data or [])
                msg.offers_count = n
                msg.status = "PARSED" if n else "NO_OFFERS"
                msg.error = None
                g = s.get(Group, msg.group_id)
                if g is not None and (tin or tout):
                    g.ai_checked = (g.ai_checked or 0) + 1
                    g.ai_hits = (g.ai_hits or 0) + (1 if n else 0)
                    if settings.AUTO_PAUSE_AFTER and g.ai_checked >= settings.AUTO_PAUSE_AFTER and not g.ai_hits:
                        g.ai_paused = True
                        log.info("AI paused for group %s: no watches in %d messages", g.name, g.ai_checked)
            s.commit()
            if status == "OK":
                new_ids += [o.id for o in created]
    if new_ids:
        try:
            await alerts.process_new_offers(new_ids)
        except Exception:  # noqa: BLE001 - alerts must never stop parsing
            log.exception("alert processing failed")
    return len(msgs), errors


STATE = {"last_ai_run": None, "next_ai_run": None}


async def run_forever() -> None:
    log.info("worker started")
    last_fx = last_house = None
    last_clean = None
    while True:
        try:
            if last_fx is None or utcnow() - last_fx > timedelta(hours=12):
                await fx.refresh()
                last_fx = utcnow()
            if last_house is None or utcnow() - last_house > timedelta(minutes=5):
                last_house = utcnow()
                await alerts.maybe_send_digest()
                if utcnow().hour == 3 and last_clean != utcnow().date():  # nightly photo cleanup
                    last_clean = utcnow().date()
                    with SessionLocal() as s:
                        media.cleanup(s)
                        s.query(LineCache).filter(LineCache.created_at < utcnow() - timedelta(days=45)).delete()
                        s.commit()
            interval = settings.AI_INTERVAL_MINUTES
            if interval > 0 and STATE["next_ai_run"] and utcnow() < STATE["next_ai_run"]:
                await asyncio.sleep(5)          # waiting for the next scheduled AI run
                continue
            n, errors = await process_batch()
            if n == 0:                          # queue empty -> schedule the next run
                STATE["last_ai_run"] = utcnow()
                STATE["next_ai_run"] = utcnow() + timedelta(minutes=interval) if interval > 0 else None
                await asyncio.sleep(3)
            elif errors:
                await asyncio.sleep(30)
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001
            log.exception("worker loop error")
            await asyncio.sleep(10)
