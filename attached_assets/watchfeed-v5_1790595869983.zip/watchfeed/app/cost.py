"""AI cost control: line-level reuse, safe call sizes and the budget.

Dealers repost the same price list every day with a few changes, and paste it into many groups.
We remember what the AI said for every *line* (together with the message's header lines, which can change
meaning, e.g. "all HKD"), so only new or changed lines ever go to the AI.
"""
import hashlib
import re
from dataclasses import dataclass, field
from typing import Optional

from .parser import looks_like_offer

MAX_CONTEXT_LINES = 8     # header/footer lines sent with every chunk (flags, "all HKD", brand headers)
CONTEXT_CHARS = 120


def _norm(line: str) -> str:
    return re.sub(r"\s+", " ", line.strip().lower())


@dataclass
class Plan:
    lines: list                      # original lines
    cand: list                       # indices of offer-like lines
    ctx: list                        # indices of context lines (kept, capped)
    sig: str                         # hash of context lines -> part of every line key
    keys: dict = field(default_factory=dict)  # cand index -> cache key


def plan(text: str) -> Plan:
    lines = text.splitlines()
    cand, ctx = [], []
    for i, ln in enumerate(lines):
        if not ln.strip():
            continue
        (cand if looks_like_offer(ln) else ctx).append(i)
    ctx = ctx[:MAX_CONTEXT_LINES]
    sig = hashlib.sha1("\n".join(_norm(lines[i])[:CONTEXT_CHARS] for i in ctx).encode()).hexdigest()[:16]
    p = Plan(lines=lines, cand=cand, ctx=ctx, sig=sig)
    p.keys = {i: hashlib.sha1(f"{sig}|{_norm(lines[i])}".encode()).hexdigest() for i in cand}
    return p


@dataclass
class Item:
    """One piece of a message sent to the AI."""
    text: str
    orig: list          # reduced line number (1-based) -> original line index or None (context)
    n_cand: int


def make_items(p: Plan, todo: list, max_lines: int) -> list:
    """Split the uncached candidate lines into AI-sized chunks, each with the message's context lines."""
    items = []
    for start in range(0, len(todo), max_lines):
        chunk = set(todo[start:start + max_lines])
        keep = sorted(chunk | {i for i in p.ctx})
        text_lines, orig = [], []
        for i in keep:
            ln = p.lines[i] if i in chunk else p.lines[i][:CONTEXT_CHARS]
            text_lines.append(ln)
            orig.append(i if i in chunk else None)
        items.append(Item(text="\n".join(text_lines), orig=orig, n_cand=len(chunk)))
    return items


def batches(items: list, max_lines: int, max_items: int) -> list:
    """Group items (each (key, Item)) into AI calls by total candidate lines and count."""
    out, cur, lines = [], [], 0
    for key, it in items:
        if cur and (len(cur) >= max_items or lines + it.n_cand > max_lines):
            out.append(cur)
            cur, lines = [], 0
        cur.append((key, it))
        lines += it.n_cand
    if cur:
        out.append(cur)
    return out


def assign(p: Plan, it: Item, offers: list) -> tuple:
    """Map AI offers for an item back to original candidate lines.
    Returns ({cand_index: [offers]}, [offers not tied to a candidate line])."""
    per_line = {i: [] for i in it.orig if i is not None}
    loose = []
    for o in offers:
        target = None
        for ln in o.get("_lines") or []:
            if isinstance(ln, int) and 1 <= ln <= len(it.orig) and it.orig[ln - 1] is not None:
                target = it.orig[ln - 1]
                break
        clean = {k: v for k, v in o.items() if k != "_lines"}
        (per_line[target] if target is not None else loose).append(clean)
    return per_line, loose


# ---------------------------------------------------------------- budget
def usd(tokens_in: int, tokens_out: int, price_in: float, price_out: float) -> float:
    return (tokens_in or 0) / 1e6 * price_in + (tokens_out or 0) / 1e6 * price_out


def daily_limit(monthly: float, daily: Optional[float]) -> float:
    return daily if daily else monthly / 30.0
